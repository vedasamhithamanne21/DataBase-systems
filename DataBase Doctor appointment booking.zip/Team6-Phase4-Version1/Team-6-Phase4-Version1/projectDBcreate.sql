
CREATE TABLE Fall22_S003_6_HOSPITAL(
	H_code	 char(20) 	not null,
	H_name	 varchar(50) 	not null,
	H_city	 varchar(50) 	not null,
	H_street	 varchar(50) 	not null,
	H_Zipcode	 varchar(50) 	not null,
	H_contact	 varchar(50) 	not null,
	H_specilization	 varchar(50) 	not null,
	primary key(H_code),
	unique(H_contact)
);

CREATE TABLE Fall22_S003_6_DOCTOR(
	D_ID	 char(20) 	not null,
	D_Name	 varchar(50) 	not null,
	D_Gender	 varchar(50) 	not null,
	D_Contact	 varchar(50) 	not null,
	D_email	 varchar(50) 	not null,
	D_Joiningdate	 date,
	H_code	 char(20)	not null,
	primary key(D_ID),
	foreign key(H_code) references Fall22_S003_6_HOSPITAL(H_Code)
		on delete cascade,
	unique(D_Contact)
);

CREATE TABLE Fall22_S003_6_PATIENT(
	P_ID	 char(20) 	not null,
	P_Name	 varchar(50) 	not null,
	P_Gender	 varchar(50) 	not null,
	P_DOB	 date,
	P_City	 varchar(50) 	not null,
	P_street	 varchar(50) 	not null,
	P_Zipcode	 varchar(50) 	not null,
	P_Insurance	 varchar(20) 	not null,
	P_Tests	 varchar(50) 	not null,
	Prescription_Details varchar(100) 	not null,
	D_ID	 char(20) 	not null,
	primary key(P_ID),
	unique(P_Insurance)
);

CREATE TABLE Fall22_S003_6_PATIENT_PHONE(
	P_ID	 char(20) 	not null,
	P_Phonenumber	 varchar(50) 	not null,
	primary key(P_ID,P_Phonenumber)
);

CREATE TABLE Fall22_S003_6_PHARMACY(
	PH_Code		varchar(50)	not null,
	P_Insurance		varchar(50)	not null,
	PH_Contact		varchar(50),
	Pharmacist varchar(50)		not null,
	H_code	 char(20) 	not null,
	P_ID	 char(20) 	not null,
	Prescription_Details varchar(100) 	not null,
	primary key(PH_Code),
	foreign key(H_code) references Fall22_S003_6_HOSPITAL(H_Code)
		on delete cascade,
	unique(PH_Contact)
);

CREATE TABLE Fall22_S003_6_LABS(
	Lab_No	char(20)		not null,
	P_Tests	 varchar(50),
	Phebotomists varchar(50)		not null,
	H_code	 char(20) 	not null,
	primary key(Lab_No),
	foreign key(H_Code) references Fall22_S003_6_HOSPITAL(H_Code)
		on delete cascade
);

CREATE TABLE Fall22_S003_6_BILLING_DETAILS(
	Booking_ID		varchar(20)		not null,
	P_Insurance  varchar(50)	not null,
	Payment_status  varchar(50)	not null,
	Date_of_Appointment	 date,
	Mode_of_payment  varchar(50)	not null,
	primary key(Booking_ID)
);

CREATE TABLE Fall22_S003_6_MANAGES(
	H_code	 char(20) 	not null,
	Booking_ID		varchar(20)		not null,
	P_ID	 char(20) 	not null,
	primary key(H_code, Booking_ID, P_ID)	
);

CREATE TABLE Fall22_S003_6_APPOINTMENT_BOOKING(
	D_ID	 char(20) 	not null,
	H_code	 char(20) 	not null,
	P_ID	 char(20) 	not null,	
	Problem_Description  varchar(50)	not null,
	Booking_ID		varchar(20)		not null,
	Appointment_slots date,
	Rating  char(20)		not null,
	primary key(D_ID,H_Code,P_ID)
);


