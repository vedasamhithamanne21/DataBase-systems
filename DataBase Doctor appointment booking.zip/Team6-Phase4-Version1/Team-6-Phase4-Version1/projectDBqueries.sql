


-----------------------------------------------------------------------

--1.Who are the 5 oldest patients?
--Fetch query

SELECT DISTINCT P_DOB
FROM Fall22_S003_6_PATIENT
ORDER BY P_DOB ASC
FETCH FIRST 5 ROWS ONLY;

------------------------------------------------------------------------

--2. Which month patients booked most appointments?
--CUBE query

select EXTRACT(Year FROM A.Appointment_slots) as year,  TO_CHAR(TO_DATE(EXTRACT(month FROM A.Appointment_slots),'MM'),'MONTH') AS "MONTH NAME" , count(*) as "Number of patients booked appointment"
from Fall22_S003_6_APPOINTMENT_BOOKING A, Fall22_S003_6_HOSPITAL P
where A.H_Code = P.H_Code
GROUP BY CUBE(EXTRACT(month FROM A.Appointment_slots), EXTRACT(Year FROM A.Appointment_slots))
order by EXTRACT(month FROM A.Appointment_slots) ASC,YEAR ASC,count(*) ASC;


-----------------------------------------------------------------------------

--3.Which type of tests that most patients taken?
--- over query

select * from Fall22_S003_6_LABS;
WITH CTE AS (
  select Lab_No, H_Code , COUNT(*) as CNT from Fall22_S003_6_LABS
  group by Lab_No
 ) select Lab_No, H_Code as "Lab" from  
  (select Lab_No, H_Code, cnt,dense_rank() over(partition by Lab_No  order by cnt desc) as DRNK  from CTE)
   where DRNK <= 1;

---------------------------------------------------------------------------------------------------

---- 4.Finding Booking ID's of patients who have partially paid
---- Order By query

SELECT COUNT(Booking_ID),Payment_status
FROM Fall22_S003_6_BILLING_DETAILS
GROUP BY Payment_status
HAVING (Payment_status='PARTIALLY PAID')
ORDER BY COUNT(Booking_ID) ASC;


------------------------------------------------------------------------------------------------

------5.which hospital manages more than 1 appointment

with CTE as(
SELECT M.D_ID, H.H_code , COUNT(*) as cpt
FROM Fall22_S003_6_DOCTOR H,Fall22_S003_6_APPOINTMENT_BOOKING M
WHERE H.H_Code=M.H_Code
GROUP BY M.D_ID, H.H_code
HAVING COUNT(*)>1) SELECT c.D_ID , b.H_code, c.cpt, b.H_name FROM CTE c, Fall22_S003_6_HOSPITAL b WHERE c.H_code=b.H_code;

----------------------------------------------------------------------------------------------------

--6. Which year patients booked most appointments?
--ROLLUP query

select EXTRACT(Year FROM A.Appointment_slots) as year,   count(*) as "Number of patients booked appointment"
from Fall22_S003_6_APPOINTMENT_BOOKING A, Fall22_S003_6_HOSPITAL P
where A.H_Code = P.H_Code
GROUP BY ROLLUP( EXTRACT(Year FROM A.Appointment_slots))
order by "Number of patients booked appointment" ASC;

-------------------------------------------------------------------------------------------------------
---7.which doctor has rating greater than 3 ?




SELECT ab.D_ID,AVG(ab.Rating) as avg1
FROM Fall22_S003_6_APPOINTMENT_BOOKING ab 
GROUP BY D_ID
HAVING AVG(ab.Rating)>'3';