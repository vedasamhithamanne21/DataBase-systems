

Select count(*) from Fall22_S003_6_DOCTOR;
insert into Fall22_S003_6_DOCTOR (D_ID, D_Name, D_Gender, D_Contact, D_email, D_Joiningdate, H_code) values ('999999', 'VAIDHYA', 'FEMALE', '850-102-5032', 'vaidhya@gmail.com ', to_date('22-Jan-2016','dd-Mon-yyyy'), '0378-6725');
insert into Fall22_S003_6_DOCTOR (D_ID, D_Name, D_Gender, D_Contact, D_email, D_Joiningdate, H_code) values ('888888', 'ROI', 'MALE', '850-103-5032', 'roi@gmail.com ', to_date('22-Jan-2016','dd-Mon-yyyy'), '0378-6725');
insert into Fall22_S003_6_DOCTOR (D_ID, D_Name, D_Gender, D_Contact, D_email, D_Joiningdate, H_code) values ('666666', 'RIYA', 'FEMALE', '850-104-5032', 'riya@gmail.com ', to_date('22-Jan-2016','dd-Mon-yyyy'), '0378-6725');
insert into Fall22_S003_6_DOCTOR (D_ID, D_Name, D_Gender, D_Contact, D_email, D_Joiningdate, H_code) values ('555555', 'ROSE', 'MALE', '850-105-5032', 'rose@gmail.com ', to_date('22-Jan-2016','dd-Mon-yyyy'), '0378-6725');
Select count(*) from Fall22_S003_6_DOCTOR;

--------------
---the following updates the doctor name with vaidhya as vaidhyaress so vaidhya shouldnt be appearing after this
UPDATE	Fall22_S003_6_DOCTOR
SET	D_Name='VAIDHYARESS', D_email='vaidhyaress@gmail.com'
WHERE	D_ID='999999';


